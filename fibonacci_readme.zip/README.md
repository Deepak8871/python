# 📘 Fibonacci Series Generator

A simple and efficient implementation of the Fibonacci series using Python. This project demonstrates different approaches to generate Fibonacci numbers, useful for beginners learning programming, algorithms, and recursion.

## 🚀 Features
- Generate Fibonacci series up to n terms  
- Iterative, Recursive, and Optimized approaches  
- Beginner-friendly code  

## 📌 Fibonacci Series
0, 1, 1, 2, 3, 5, 8, 13, ...

## 🧑‍💻 Usage
Run the Python script:
python fibonacci.py

## 💡 Example Output
0 1 1 2 3 5 8 13 21 34

## ⚡ Complexity
Iterative: O(n)  
Recursive: O(2^n)  

## 📂 Structure
fibonacci-generator/
│── fibonacci.py
│── README.md

## 📜 License
MIT License
